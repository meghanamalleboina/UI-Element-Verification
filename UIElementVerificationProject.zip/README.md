# UI Element Verification Project

Automates verification of:
- Username field
- Password field
- Login button

Technologies:
- Java
- Selenium WebDriver
- TestNG
- Maven